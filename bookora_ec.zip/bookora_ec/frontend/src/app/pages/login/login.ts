import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { NgIf } from '@angular/common';
import Swal from 'sweetalert2';
import { ApiService } from '../../core/services/api.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    FormsModule,
    RouterLink,
    NgIf
  ],
  templateUrl: './login.html',
  styleUrl: './login.css'
})

export class LoginComponent {

  email = '';

  password = '';

  error = '';

  constructor(
    private api: ApiService,
    private router: Router
  ) { }

  login() {

    // VALIDAR CAMPOS

    if (!this.email || !this.password) {

      Swal.fire({

        icon: 'warning',

        title: 'Campos incompletos',

        text: 'Complete todos los campos',

        background: '#0f172a',

        color: '#fff',

        confirmButtonColor: '#ec4899'

      });

      return;
    }

    // LOGIN API

    this.api.login({

      email: this.email,

      password: this.password

    }).subscribe((res: any) => {

      console.log(res);

      // ERROR LOGIN

      if (res.error) {

        Swal.fire({

          icon: 'error',

          title: 'Error',

          text: res.error,

          background: '#0f172a',

          color: '#fff',

          confirmButtonColor: '#ec4899'

        });

        return;
      }

      // GUARDAR USUARIO

      localStorage.setItem(
        'user',
        JSON.stringify(res)
      );

      // REDIRECCION SEGUN ROL

      switch (Number(res.rol_id)) {

        // ADMIN

        case 1:

          this.router.navigate([
            '/admin-dashboard'
          ]);

          break;

        // CLIENTE

        case 2:

          this.router.navigate([
            '/dashboard'
          ]);

          break;

        // ERROR

        default:

          Swal.fire({

            icon: 'error',

            title: 'Rol desconocido',

            text: 'No se puede redirigir, rol inválido.',

            background: '#0f172a',

            color: '#fff',

            confirmButtonColor: '#ec4899'

          });

      }

    });

  }

}
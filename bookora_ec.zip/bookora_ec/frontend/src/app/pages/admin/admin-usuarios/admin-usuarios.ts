import { Component, OnInit } from '@angular/core';

import { CommonModule } from '@angular/common';

import Swal from 'sweetalert2';

import { SidebarAdminComponent }
  from '../../../shared/sidebar-admin/sidebar-admin';

import { ApiService }
  from '../../../core/services/api.service';

@Component({
  selector: 'app-admin-usuarios',
  standalone: true,

  imports: [
    CommonModule,
    SidebarAdminComponent
  ],

  templateUrl: './admin-usuarios.html',

  styleUrls: ['./admin-usuarios.css']
})

export class AdminUsuariosComponent
  implements OnInit {

  usuarios: any[] = [];

  constructor(
    private api: ApiService
  ) { }

  ngOnInit(): void {

    this.cargarUsuarios();
  }

  cargarUsuarios() {

    this.api.getUsuarios()
      .subscribe({

        next: (res: any) => {

          console.log('USUARIOS:', res);

          this.usuarios = Array.isArray(res)
            ? res
            : res.usuarios || [];

        },

        error: (err) => {

          console.error('ERROR API:', err);

        }

      });
  }

  estaOnline(fecha: string): boolean {

    if (!fecha) return false;

    const ultima =
      new Date(fecha).getTime();

    const ahora =
      new Date().getTime();

    const diferencia =
      (ahora - ultima) / 1000;

    return diferencia < 60;
  }

  tiempoActivo(fecha: string): string {

    if (!fecha) {

      return 'Sin actividad';
    }

    const ultima =
      new Date(fecha).getTime();

    const ahora =
      new Date().getTime();

    const minutos =
      Math.floor((ahora - ultima) / 60000);

    // SEGUNDOS

    if (minutos < 1) {

      return 'Activo hace unos segundos';
    }

    // MINUTOS

    if (minutos < 60) {

      return `Activo hace ${minutos} minuto(s)`;
    }

    // HORAS

    const horas =
      Math.floor(minutos / 60);

    if (horas < 24) {

      return `Activo hace ${horas} hora(s)`;
    }

    // DIAS

    const dias =
      Math.floor(horas / 24);

    return `Activo hace ${dias} día(s)`;
  }

  eliminarUsuario(id: number) {

    Swal.fire({

      title: '¿Eliminar usuario?',

      text: 'El usuario será eliminado.',

      icon: 'warning',

      background: '#0f172a',

      color: '#fff',

      showCancelButton: true,

      confirmButtonColor: '#ec4899',

      cancelButtonColor: '#334155',

      confirmButtonText: 'Sí, eliminar',

      cancelButtonText: 'Cancelar'

    }).then((result) => {

      if (result.isConfirmed) {

        this.api.eliminarUsuario(id)
          .subscribe(() => {

            Swal.fire({

              icon: 'success',

              title: 'Usuario eliminado',

              background: '#0f172a',

              color: '#fff',

              confirmButtonColor: '#ec4899'

            });

            this.cargarUsuarios();

          });
      }
    });
  }
}
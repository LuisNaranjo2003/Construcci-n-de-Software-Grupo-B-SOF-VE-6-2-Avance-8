import { Component, OnInit } from '@angular/core';

import { FormsModule } from '@angular/forms';

import { CommonModule } from '@angular/common';

import Swal from 'sweetalert2';

import { SidebarAdminComponent }
  from '../../../shared/sidebar-admin/sidebar-admin';

import { ApiService }
  from '../../../core/services/api.service';

@Component({
  selector: 'app-admin-servicios',
  standalone: true,

  imports: [
    FormsModule,
    CommonModule,
    SidebarAdminComponent
  ],

  templateUrl: './admin-servicios.html',

  styleUrls: ['./admin-servicios.css']
})

export class AdminServiciosComponent
  implements OnInit {

  servicios: any[] = [];

  form = {
    nombre: '',
    descripcion: '',
    duracion: 0,
    precio: 0,
    imagen: null as File | null
  };

  constructor(
    private api: ApiService
  ) { }

  ngOnInit(): void {

    this.cargarServicios();
  }

  cargarServicios() {

    this.api.getServicios()
      .subscribe((res: any) => {

        this.servicios = res;
      });
  }

  seleccionarImagen(event: any) {

    const file =
      event.target.files[0];

    if (file) {

      this.form.imagen = file;
    }
  }

  crearServicio() {

    if (
      !this.form.nombre ||
      !this.form.duracion ||
      !this.form.precio
    ) {

      Swal.fire({

        icon: 'error',

        title: 'Campos incompletos',

        background: '#0f172a',

        color: '#fff',

        confirmButtonColor: '#ec4899'

      });

      return;
    }

    const formData =
      new FormData();

    formData.append(
      'nombre',
      this.form.nombre
    );

    formData.append(
      'descripcion',
      this.form.descripcion
    );

    formData.append(
      'duracion',
      this.form.duracion.toString()
    );

    formData.append(
      'precio',
      this.form.precio.toString()
    );

    if (this.form.imagen) {

      formData.append(
        'imagen',
        this.form.imagen
      );
    }

    this.api.crearServicio(formData)
      .subscribe(() => {

        Swal.fire({

          icon: 'success',

          title: 'Servicio creado',

          background: '#0f172a',

          color: '#fff',

          confirmButtonColor: '#ec4899'

        });

        this.form = {

          nombre: '',
          descripcion: '',
          duracion: 0,
          precio: 0,
          imagen: null
        };

        this.cargarServicios();

      });
  }

  eliminar(id: number) {

    Swal.fire({

      title: '¿Eliminar servicio?',

      icon: 'warning',

      showCancelButton: true,

      background: '#0f172a',

      color: '#fff',

      confirmButtonColor: '#ec4899'

    }).then(result => {

      if (result.isConfirmed) {

        this.api.eliminarServicio(id)
          .subscribe(() => {

            Swal.fire({

              icon: 'success',

              title: 'Servicio eliminado',

              background: '#0f172a',

              color: '#fff',

              confirmButtonColor: '#ec4899'

            });

            this.cargarServicios();

          });
      }
    });
  }
}
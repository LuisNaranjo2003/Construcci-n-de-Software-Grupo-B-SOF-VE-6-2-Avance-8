import { Component, OnInit } from '@angular/core';

import { CommonModule } from '@angular/common';

import { FormsModule } from '@angular/forms';

import { SidebarAdminComponent }
  from '../../../shared/sidebar-admin/sidebar-admin';

import { ApiService }
  from '../../../core/services/api.service';

@Component({
  selector: 'app-admin-reportes',
  standalone: true,

  imports: [
    CommonModule,
    FormsModule,
    SidebarAdminComponent
  ],

  templateUrl: './admin-reportes.html',

  styleUrls: ['./admin-reportes.css']
})

export class AdminReportesComponent
  implements OnInit {

  constructor(
    private api: ApiService
  ) { }

  ngOnInit(): void { }

  generarPDF() {

    alert(
      'PDF generado (a implementar con jsPDF)'
    );
  }
}
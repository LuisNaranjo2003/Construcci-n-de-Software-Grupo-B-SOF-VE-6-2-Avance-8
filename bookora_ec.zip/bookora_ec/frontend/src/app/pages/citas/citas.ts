import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgFor, NgIf } from '@angular/common';

import Swal from 'sweetalert2';

import { SidebarComponent } from '../../shared/sidebar/sidebar';

import { ApiService } from '../../core/services/api.service';

@Component({
  selector: 'app-citas',
  standalone: true,
  imports: [
    FormsModule,
    NgFor,
    SidebarComponent
  ],
  templateUrl: './citas.html',
  styleUrl: './citas.css'
})
export class CitasComponent implements OnInit {

  citas: any[] = [];

  servicios: any[] = [];

  mensaje = '';

  form = {
    usuario_id: '',
    servicio_id: '',
    fecha: '',
    hora: ''
  };

  constructor(
    private api: ApiService
  ) { }

  ngOnInit(): void {

    const user = JSON.parse(
      localStorage.getItem('user')!
    );

    this.form.usuario_id = user.usuario_id;

    this.cargarCitas();

    this.cargarServicios();
  }

  cargarCitas() {

    this.api.getCitas()
      .subscribe((res: any) => {

        this.citas = res;
      });
  }

  cargarServicios() {

    this.api.getServicios()
      .subscribe((res: any) => {

        this.servicios = res;
      });
  }

  crearCita() {

    // VALIDAR CAMPOS

    if (
      !this.form.servicio_id ||
      !this.form.fecha ||
      !this.form.hora
    ) {

      Swal.fire({

        icon: 'warning',

        title: 'Campos incompletos',

        text: 'Complete todos los campos',

        background: '#0f172a',

        color: '#fff',

        confirmButtonColor: '#ec4899'
      });

      return;
    }

    // VALIDAR HORARIO

    const hora = parseInt(
      this.form.hora.split(':')[0]
    );

    if (hora < 9 || hora >= 23) {

      Swal.fire({

        icon: 'error',

        title: 'Horario inválido',

        text: 'Solo se permiten reservas entre 09:00 AM y 11:00 PM',

        background: '#0f172a',

        color: '#fff',

        confirmButtonColor: '#ec4899'
      });

      return;
    }

    // CREAR CITA

    this.api.crearCita(this.form)
      .subscribe((res: any) => {

        if (res.error) {

          Swal.fire({

            icon: 'error',

            title: 'Error',

            text: res.error,

            background: '#0f172a',

            color: '#fff',

            confirmButtonColor: '#ec4899'
          });

          return;
        }

        Swal.fire({

          icon: 'success',

          title: 'Cita reservada',

          text: 'La cita fue creada correctamente',

          background: '#0f172a',

          color: '#fff',

          confirmButtonColor: '#ec4899'
        });

        this.form.servicio_id = '';
        this.form.fecha = '';
        this.form.hora = '';

        this.cargarCitas();

      });
  }

  cancelar(id: number) {

    Swal.fire({

      title: '¿Cancelar cita?',

      text: 'La cita será cancelada.',

      icon: 'warning',

      background: '#0f172a',

      color: '#fff',

      showCancelButton: true,

      confirmButtonColor: '#ec4899',

      cancelButtonColor: '#334155',

      confirmButtonText: 'Sí, cancelar',

      cancelButtonText: 'No'

    }).then((result) => {

      if (result.isConfirmed) {

        this.api.cancelarCita({
          cita_id: id
        }).subscribe((res: any) => {

          Swal.fire({

            icon: 'success',

            title: 'Cita cancelada',

            text: res.mensaje,

            background: '#0f172a',

            color: '#fff',

            confirmButtonColor: '#ec4899'
          });

          this.cargarCitas();

        });
      }
    });
  }
}
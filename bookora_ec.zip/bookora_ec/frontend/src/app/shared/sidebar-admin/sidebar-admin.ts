import { Component } from '@angular/core';

import {
    Router,
    RouterModule,
    NavigationEnd
} from '@angular/router';

import Swal from 'sweetalert2';

@Component({
    selector: 'app-sidebar-admin',
    standalone: true,

    imports: [
        RouterModule
    ],

    templateUrl: './sidebar-admin.html',

    styleUrls: ['./sidebar-admin.css']
})

export class SidebarAdminComponent {

    activo = false;

    constructor(
        private router: Router
    ) {

        // CERRAR SIDEBAR AL CAMBIAR RUTA

        this.router.events.subscribe(event => {

            if (event instanceof NavigationEnd) {

                this.activo = false;
            }

        });

    }

    toggleSidebar() {

        this.activo = !this.activo;
    }

    cerrarSidebar() {

        this.activo = false;
    }

    logout() {

        Swal.fire({

            title: '¿Estás seguro?',

            text: 'La sesión actual será cerrada.',

            icon: 'warning',

            background: '#0f172a',

            color: '#ffffff',

            showCancelButton: true,

            confirmButtonColor: '#ec4899',

            cancelButtonColor: '#334155',

            confirmButtonText: 'Sí, cerrar sesión',

            cancelButtonText: 'Cancelar'

        }).then((result) => {

            if (result.isConfirmed) {

                localStorage.removeItem('user');

                this.router.navigate(['']);

            }

        });

    }

}
import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { NgIf } from '@angular/common';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [RouterLink, NgIf],
  templateUrl: './sidebar.html',
  styleUrl: './sidebar.css'
})
export class SidebarComponent {

  activo = false;
  user: any = JSON.parse(localStorage.getItem('user')!);

  constructor(private router: Router) { }

  toggleSidebar() {
    this.activo = !this.activo;
  }

  logout() {
    Swal.fire({
      title: '¿Estás seguro?',
      text: 'La sesión actual será cerrada.',
      icon: 'warning',
      background: '#0f172a',
      color: '#ffffff',
      showCancelButton: true,
      confirmButtonColor: '#ec4899',
      cancelButtonColor: '#334155',
      confirmButtonText: 'Sí, cerrar sesión',
      cancelButtonText: 'Cancelar'
    }).then((result) => {
      if (result.isConfirmed) {
        localStorage.removeItem('user');
        this.router.navigate(['/']);
      }
    });
  }

}
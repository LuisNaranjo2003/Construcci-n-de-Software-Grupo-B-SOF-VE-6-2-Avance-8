<?php
require_once '../app/core/Database.php';

class Servicio
{
    private $db;

    public function __construct()
    {
        $this->db = (new Database())->connect();
    }

    public function all()
    {
        $sql = "SELECT * FROM servicios";

        return $this->db->query($sql)
            ->fetchAll(PDO::FETCH_ASSOC);
    }

    public function create($data)
    {
        $sql = "INSERT INTO servicios
        (
            nombre,
            descripcion,
            duracion,
            precio,
            imagen
        )
        VALUES (?, ?, ?, ?, ?)";

        $stmt = $this->db->prepare($sql);

        return $stmt->execute([
            $data['nombre'],
            $data['descripcion'],
            $data['duracion'],
            $data['precio'],
            $data['imagen']
        ]);
    }

    public function delete($id)
    {
        $stmt = $this->db->prepare(
            "DELETE FROM servicios
            WHERE servicio_id = ?"
        );

        return $stmt->execute([$id]);
    }
}
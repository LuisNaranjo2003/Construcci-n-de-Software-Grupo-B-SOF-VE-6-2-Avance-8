<?php
require_once '../app/core/Database.php';

class User
{
    private $db;

    public function __construct()
    {
        $this->db = (new Database())->connect();
    }

    // LOGIN

    public function findByEmail($email)
    {
        $stmt = $this->db->prepare(
            "SELECT * FROM usuarios WHERE email=?"
        );

        $stmt->execute([$email]);

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // REGISTER

    public function create($data)
    {
        $rol = isset($data->rol_id)
            ? $data->rol_id
            : 2;

        $stmt = $this->db->prepare(
            "INSERT INTO usuarios
            (nombre,email,password,rol_id)
            VALUES(?,?,?,?)"
        );

        return $stmt->execute([
            $data->nombre,
            $data->email,
            password_hash(
                $data->password,
                PASSWORD_BCRYPT
            ),
            $rol
        ]);
    }

    // LISTAR USUARIOS

    public function getAll()
    {
        $stmt = $this->db->query(
            "SELECT 
                usuarios.usuario_id,
                usuarios.nombre,
                usuarios.email,
                usuarios.fecha_registro,
                usuarios.ultima_actividad,
                usuarios.rol_id,
                roles.nombre AS rol
            FROM usuarios
            LEFT JOIN roles
            ON usuarios.rol_id = roles.rol_id
            ORDER BY usuarios.usuario_id ASC"
        );

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // ACTUALIZAR ACTIVIDAD

    public function actualizarActividad($id)
    {
        $stmt = $this->db->prepare(
            "UPDATE usuarios
            SET ultima_actividad = NOW()
            WHERE usuario_id=?"
        );

        return $stmt->execute([$id]);
    }

    // ELIMINAR

    public function delete($id)
    {
        $stmt = $this->db->prepare(
            "DELETE FROM usuarios
            WHERE usuario_id=?"
        );

        return $stmt->execute([$id]);
    }
}
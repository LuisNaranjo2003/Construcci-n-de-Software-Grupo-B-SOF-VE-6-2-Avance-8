<?php
require_once '../app/models/Cita.php';
require_once '../app/models/Horario.php';

class CitaService
{

    private $cita;
    private $horario;

    public function __construct()
    {
        $this->cita = new Cita();
        $this->horario = new Horario();
    }

    public function crear($data)
    {

        if (!$this->horario->verificar(date('l', strtotime($data->fecha)), $data->hora)) {
            return ["error" => "Fuera de horario"];
        }

        if ($this->cita->existeCita($data->fecha, $data->hora)) {
            return ["error" => "Horario ocupado"];
        }

        $this->cita->create($data);

        return ["mensaje" => "Cita creada"];
    }
}
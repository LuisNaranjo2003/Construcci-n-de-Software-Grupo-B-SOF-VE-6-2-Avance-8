<?php
require_once '../app/core/Controller.php';
require_once '../app/models/User.php';

class AuthController extends Controller
{

    // LOGIN

    public function login()
    {
        $data = json_decode(
            file_get_contents("php://input")
        );

        $user = (new User())
            ->findByEmail($data->email);

        if (
            $user &&
            password_verify(
                $data->password,
                $user['password']
            )
        ) {

            // ACTUALIZAR ACTIVIDAD

            (new User())->actualizarActividad(
                $user['usuario_id']
            );

            // NO ENVIAR PASSWORD

            unset($user['password']);

            $this->json($user);

        } else {

            $this->json([
                "error" =>
                    "Credenciales incorrectas"
            ]);
        }
    }

    // REGISTER

    public function register()
    {
        $data = json_decode(
            file_get_contents("php://input")
        );

        $crear = (new User())
            ->create($data);

        if ($crear) {

            $this->json([
                "mensaje" =>
                    "Usuario creado"
            ]);

        } else {

            $this->json([
                "error" =>
                    "No se pudo registrar"
            ]);
        }
    }
}
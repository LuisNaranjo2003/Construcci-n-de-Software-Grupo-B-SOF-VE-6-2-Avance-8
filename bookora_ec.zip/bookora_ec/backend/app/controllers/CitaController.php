<?php

require_once '../app/core/Controller.php';
require_once '../app/services/CitaService.php';
require_once '../app/models/Cita.php';

class CitaController extends Controller
{

    private $service;

    public function __construct()
    {
        $this->service = new CitaService();
    }

    // LISTAR CITAS
    public function index()
    {
        $cita = new Cita();

        $this->json(
            $cita->all()
        );
    }

    // CREAR CITA
    public function store()
    {
        $data = json_decode(
            file_get_contents("php://input"),
            true
        );

        // VALIDAR CAMPOS
        if (
            empty($data['usuario_id']) ||
            empty($data['servicio_id']) ||
            empty($data['fecha']) ||
            empty($data['hora'])
        ) {

            $this->json([
                "error" => "Complete todos los campos"
            ]);

            return;
        }

        // VALIDAR FECHA PASADA
        $fechaActual = date('Y-m-d');

        if ($data['fecha'] < $fechaActual) {

            $this->json([
                "error" => "No puedes reservar fechas pasadas"
            ]);

            return;
        }

        // VALIDAR HORARIO DE ATENCIÓN
        $hora = strtotime($data['hora']);

        $inicio = strtotime("09:00");
        $fin = strtotime("20:00");

        if ($hora < $inicio || $hora > $fin) {

            $this->json([
                "error" => "Horario fuera de atención"
            ]);

            return;
        }

        // VALIDAR HORARIO DUPLICADO
        $cita = new Cita();

        $existe = $cita->verificarHorario(
            $data['fecha'],
            $data['hora']
        );

        if ($existe) {

            $this->json([
                "error" => "Horario ocupado"
            ]);

            return;
        }

        // CREAR CITA
        $result = $this->service->crear($data);

        $this->json($result);
    }

    // CANCELAR CITA
    public function cancelar()
    {
        $data = json_decode(
            file_get_contents("php://input"),
            true
        );

        $cita = new Cita();

        $cita->cancelar(
            $data['cita_id']
        );

        $this->json([
            "mensaje" => "Cita cancelada"
        ]);
    }
}
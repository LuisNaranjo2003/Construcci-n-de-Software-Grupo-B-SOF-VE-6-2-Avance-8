<?php
class Controller
{

    protected function model($model)
    {
        require_once '../app/models/' . $model . '.php';
        return new $model();
    }

    protected function json($data)
    {
        echo json_encode($data);
    }
}
<?php
define("BASE_URL", "http://localhost/bookora_ec/backend/public");